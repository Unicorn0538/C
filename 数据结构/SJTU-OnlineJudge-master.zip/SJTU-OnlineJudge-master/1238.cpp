#include <iostream>
using namespace std;
int main()
{
    int a,b,c,t=0;
    cin>>a>>b>>c;
    if (t<a) t=a;
    if (t<b) t=b;
    if (t<c) t=c;
    cout<<t;
}
