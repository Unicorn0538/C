#include <iostream>
using namespace std;
int main()
{
    int year[2][7]={{252,252,253,254,254,253,252},{253,254,255,255,253,252,253}};
}
