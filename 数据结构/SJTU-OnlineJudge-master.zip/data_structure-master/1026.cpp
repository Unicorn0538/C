#include <iostream>
#include <cstring>
#define MAX 1001
using namespace std;

//int len(char x);
int main(){
    char a[MAX]={'0'},b[MAX]={'0'};
    int lena,lenb;
    cin>>a>>b;
    lena=strlen(a);
    lenb=strlen(b);
    //cout<<strlen(a);


    return 0;
}
//int len(char x){

//}
