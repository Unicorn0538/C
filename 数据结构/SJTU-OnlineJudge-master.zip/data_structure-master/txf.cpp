#include <iostream>
using namespace std;

int main(){
    cout<<"this is my first time to learn github";
    return 0;
}