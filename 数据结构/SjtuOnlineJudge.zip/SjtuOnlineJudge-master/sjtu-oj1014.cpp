//passed
//just HP int
//See also "sjtu-oj1026"
