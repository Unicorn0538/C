#include <iostream>

using namespace std;

int main()
{
	long long n, m;
	long long res;
	cin >> n >> m;
	res = n + m;
	cout << res << endl;
	return 0;
}