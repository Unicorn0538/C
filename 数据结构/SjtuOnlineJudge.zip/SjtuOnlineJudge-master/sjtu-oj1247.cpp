//pass
//simple simulation
//because L & M are too small
int main() {
	return 0;
}