/* 小M的机器人 */
#include <iostream>
using namespace std;

int main(){
    long long m, n;
    cin >> m >> n;
    cout << m + n << endl;
    return 0;
}
