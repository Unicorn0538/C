/* 二哥的赌博 */
#include <iostream>
using namespace std;

int main(){
    int m;
    cin >> m;
    while (m--){
        int t;
        cin >> t;
        if (t == 0)
            cout << "no" << endl;
        else
            cout << "yes" << endl;
    }
    return 0;
}
